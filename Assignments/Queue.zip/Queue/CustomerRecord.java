public class CustomerRecord {
	private int arrivalTime, helpTime;
	public CustomerRecord(int arrivalTime, int helpTime) {
		this.arrivalTime = arrivalTime;
		this.helpTime = helpTime;
	}
	public int getArrivalTime() {
		return arrivalTime;
	}
	public int getHelpTime() {
		return helpTime;
	}
}
